#' Utility function for GenomicRanges.
#'
#' \tabular{ll}{
#' Package: \tab grUtils\cr
#' Type: \tab Package\cr
#' Version: \tab 0.1\cr
#' Date: \tab 2015-05-17\cr
#' Depends: \tab R (>= 3.0), GenomicRanges (>= 1.18), data.table (>= 1.9)\cr
#' License: \tab GPL (>= 3)\cr
#' LazyLoad: \tab yes\cr
#' }
#'
#' Utility function for GenomicRanges and Rsamtools
#'
#' @aliases grUtils-package
#' @name grUtils-package
#' @docType package
#' @title The grUtils Package
#' @author Jeremiah Wala and Marcin Imielinski
#' @keywords package
NULL
